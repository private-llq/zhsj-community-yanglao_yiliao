package com.zhsj.community.yanglao_yiliao.old_activity.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.zhsj.community.yanglao_yiliao.old_activity.model.ActivityDetails;
import org.springframework.stereotype.Repository;



@Repository
public interface  ActivityDetailsMapper extends BaseMapper<ActivityDetails> {


}
